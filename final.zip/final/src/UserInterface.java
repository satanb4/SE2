import java.io.FileNotFoundException;
import java.io.IOException;

public interface UserInterface {
    public void createrole(User user) throws IOException;


}
