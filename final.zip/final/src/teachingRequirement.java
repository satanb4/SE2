//package ae;
import java.util.ArrayList;
public class teachingRequirement {
    private String skill;
    private String qualification;


    public teachingRequirement(String skill, String qualification) {
        this.skill = skill;
        this.qualification = qualification;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }


}

